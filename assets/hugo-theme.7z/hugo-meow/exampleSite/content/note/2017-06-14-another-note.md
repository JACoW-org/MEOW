---
title: Another Note on A blogdown Tutorial
author: Yihui Xie
date: '2017-06-14'
categories:
  - Example
tags:
  - Tutorial
slug: another-note
---

I just discovered [an awesome tutorial](https://www.apreshill.com/blog/2020-12-new-year-new-blogdown/) on **blogdown** written by Alison. I have to admit this is _the_ best **blogdown** tutorial I have seen so far.

![Alison's blogdown tutorial](https://www.apreshill.com/blog/2020-12-new-year-new-blogdown/03-blogdown-2021.png)
